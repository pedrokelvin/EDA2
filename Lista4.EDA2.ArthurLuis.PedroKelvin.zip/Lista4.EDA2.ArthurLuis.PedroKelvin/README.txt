Lista 4 de EDA2 - 2/2017

Os problemas resolvidos foram 4, 5, 7, 12, 13. Ha um Makefile para ajudar a compilar os programas.
Todos os problemas foram escritos em C++. A explicação de cada exercício está nos comentários dos códigos.

Alunos: Arthur Luis Komatsu Aroeira - 13/0102750
		Pedro Kelvin de Castro M Batista - 13/0129674