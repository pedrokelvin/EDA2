para executar as questoes, foi criado um Makefile para melhor organizacao:
make questao1
make questao2
make questao3
make questao4